<?php

//namespace Container;

interface Container
{
	public function square($width,$length);
    public function circle($radius);

}