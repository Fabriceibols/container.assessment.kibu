<?php

class CalculationAlias
{

    public function __construct()
    {
    }
}